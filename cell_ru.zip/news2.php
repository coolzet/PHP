<?php
require_once ('login.php');
$connect = new MYSQLI($hn, $un, $pw, $db);
if($connect->connect_error) die("Fatal Error");
$news1 = 'SELECT * FROM `news` ORDER BY `id` DESC';
$result = $connect->query($news1);

$rows = $result->num_rows;
$rows -= 2;

$result->data_seek($rows);
$row = $result->fetch_array(MYSQLI_ASSOC);



echo '<h2>'. $row['title'] . '</h2><br>' . $row['text'];
?>