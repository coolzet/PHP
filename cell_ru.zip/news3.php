<?php
require_once ('login.php');
$connect = new MYSQLI($hn, $un, $pw, $db);
if($connect->connect_error) die("Fatal Error");
$news1 = 'SELECT * FROM `news` ORDER BY `id` DESC';
$result = $connect->query($news1);

$rows = $result->num_rows;
$rows -= 2;

$result_1 = mysqli_query($connect, "SELECT * FROM `news` WHERE `id` = $rows;");
$row = mysqli_fetch_assoc($result_1);




echo '<h2>'. $row['title'] . '</h2><br>' . $row['text'];
?>