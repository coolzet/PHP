<?php
$hn = 'localhost';
$db = 'celldweller';
$un = 'root';
$pw = '';



?>